import SwiftUI

struct NavigationViewController: UIViewControllerRepresentable{
    func updateUIViewController(_ uiViewController: UIViewControllerType, context:Context){
        
    }
  
    func makeUIViewController(context:Context)-> some UIViewController {
        let vc = LaunchScreeenViewController()
        let navController = UINavigationController(rootViewController: vc)
        return navController
    }
}
