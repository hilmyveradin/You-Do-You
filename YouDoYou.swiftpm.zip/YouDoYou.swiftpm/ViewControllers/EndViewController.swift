//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//

import Foundation
import UIKit

class EndViewController: UIViewController {
  //MARK: - Properties
  private var endContainer: UIView = {
    let view = UIView()
    //    view.backgroundColor = .white
    //    view.layer.borderWidth = 2
    //    view.layer.borderColor = UIColor.black.cgColor
    //    view.layer.cornerRadius = 5
    view.alpha = 0
    return view
  }()
  
  private var CreditContainer: UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.alpha = 0
    return view
  }()
  
  private var endLabel : UILabel! = {
    let lbl = UILabel()
    lbl.numberOfLines = 3
    lbl.textAlignment = .center
    //    lbl.font = .systemFont(ofSize: 60)
    lbl.font = UIFont(name: "Chalkboard SE", size: 60)
    //    lbl.backgroundColor = .red
    lbl.text = "You do you! 😉"
    return lbl
  }()
  
  private var creditTitleLabel : UILabel! = {
    let lbl = UILabel()
    lbl.numberOfLines = 1
    lbl.textAlignment = .center
    lbl.font = .boldSystemFont(ofSize: 20)
    //    lbl.backgroundColor = .red
    lbl.text = "Credits:"
    return lbl
  }()
  
  private var creditBodyLabel : UILabel! = {
    let lbl = UILabel()
    lbl.numberOfLines = 0
    lbl.textAlignment = .left
    lbl.font = .systemFont(ofSize: 20)
    lbl.text = Texts.CreditTexts.credits
    //    lbl.backgroundColor = .red
    return lbl
  }()
  
  //MARK: - Life Cycles
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .systemGray6
    setupView()
    initAnimation()
  }
  
  let speech = Speech()
  //MARK: - Helpers
}

//MARK: - Setup Views
extension EndViewController {
  private func setupView() {
    view.addSubview(endContainer)
    endContainer.addSubview(endLabel)
    view.addSubview(CreditContainer)
    CreditContainer.addSubview(creditTitleLabel)
    CreditContainer.addSubview(creditBodyLabel)
    
    endContainer.anchor(top: nil, paddingTop: 0,
                        bottom: nil, paddingBottom: 0,
                        left: nil, paddingLeft: 0,
                        right: nil, paddingRight: 0,
                        width: 505, height: 128,
                        centerX: view.centerXAnchor, centerY: view.centerYAnchor,
                        enableInsets: false)
    endLabel.anchor(top: endContainer.topAnchor, paddingTop: 0,
                    bottom: endContainer.bottomAnchor, paddingBottom: 0,
                    left: endContainer.leftAnchor, paddingLeft: 0,
                    right: endContainer.rightAnchor, paddingRight: 0,
                    width: 0, height: 0,
                    centerX: nil, centerY: nil,
                    enableInsets: false)
    CreditContainer.anchor(top: endContainer.bottomAnchor, paddingTop: 26,
                           bottom: nil, paddingBottom: 0,
                           left: nil, paddingLeft: 0,
                           right: nil, paddingRight: 0,
                           width: 505, height: 239,
                           centerX: view.centerXAnchor, centerY: nil,
                           enableInsets: false)
    creditTitleLabel.anchor(top: CreditContainer.topAnchor, paddingTop: 8,
                            bottom: nil, paddingBottom: 0,
                            left: CreditContainer.leftAnchor, paddingLeft: 8,
                            right: CreditContainer.rightAnchor, paddingRight: 8,
                            width: 0, height: 50,
                            centerX: nil, centerY: nil,
                            enableInsets: false)
    creditBodyLabel.anchor(top: creditTitleLabel.bottomAnchor, paddingTop: 8,
                           bottom: CreditContainer.bottomAnchor, paddingBottom: 8,
                           left: CreditContainer.leftAnchor, paddingLeft: 8,
                           right: CreditContainer.rightAnchor, paddingRight: 8,
                           width: 0, height: 0,
                           centerX: nil, centerY: nil,
                           enableInsets: false)
  }
}

//MARK: - Animations
extension EndViewController {
  private func initAnimation() {
    UIView.animate(withDuration: 1, delay: 0, animations: {
      self.endContainer.alpha = 0
    }, completion: { (_) in
      UIView.animate(withDuration: 1, delay: 1, animations: {
        self.speech.creatorSpeak(phrase: "you do you!")
        self.endContainer.alpha = 1
      }, completion: { (_) in
        UIView.animate(withDuration: 1, delay: 2, animations: {
          self.CreditContainer.alpha = 1
        })
      })
    })
  }
}

