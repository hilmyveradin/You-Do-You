//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//

import UIKit
import Foundation
import AVFAudio

class OnBoardingViewController: UIViewController {
  
  // MARK: - Properties
  
  // View Properties
  private var welcomeLabel : UILabel! = {
    let lbl = UILabel()
//    lbl.backgroundColor = .blue
    lbl.numberOfLines = 0
    lbl.textAlignment = .center
    lbl.alpha = 0
    lbl.font = .systemFont(ofSize: 34)
    lbl.text = "Welcome To"
    return lbl
  }()
  
  private var titleLabel : UILabel = {
    let lbl = UILabel()
//    lbl.backgroundColor = .purple
    lbl.numberOfLines = 0
    lbl.textAlignment = .center
    lbl.alpha = 0
    lbl.font = UIFont(name: "Chalkboard SE", size: 60)
    lbl.text = "You Do You!"
    return lbl
  }()
  
  private var personViewContainer : UIView = {
    let view = UIView()
//    view.backgroundColor = .gray
    view.alpha = 0
    return view
  }()
  
  private var personHead : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 89/2
    return view
  }()
  private var personBody  : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    return view
  }()
  private var personRightHand : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    return view
  }()
  private var personLeftHand : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    return view
  }()
  private var personRightLeg : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    return view
  }()
  private var personLeftLeg : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    return view
  }()
  
  private var startbutton : UIButton = {
    let btn = UIButton()
    btn.backgroundColor = .orange
    btn.setTitle("I Wonder What This Is!?", for: .normal)
    btn.titleLabel?.font = UIFont.systemFont(ofSize: 28)
    btn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.8).cgColor
    btn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
    btn.layer.borderWidth = 1
    btn.layer.borderColor = UIColor.black.cgColor
    btn.layer.shadowOpacity = 1.0
    btn.layer.shadowRadius = 5
    btn.layer.cornerRadius = 15
    btn.alpha = 0
    return btn
  }()
  
  // Functional Properties
  public var audioPlayer: AVAudioPlayer?
  
  // MARK: - Life Cycles
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .systemGray6
    setupView()
    animateView()
    
  }
  
  // MARK: - Methods
  
  // Play Music
  private func playMusic() {
    let url = Bundle.main.path(forResource: "bensound-memories.mp3", ofType: nil)
    let musicUrl = URL(fileURLWithPath: url!)

    do {
      audioPlayer = try AVAudioPlayer(contentsOf: musicUrl)
      audioPlayer?.numberOfLoops = -1
      audioPlayer?.volume = 0.2
      audioPlayer?.play()
    } catch {
      print("Error in playing music \(error.localizedDescription)")
    }
  }
  
  // Animate View
  private func animateView() {
    UIView.animate(withDuration: 1, delay: 1, animations: {
      self.playMusic()
      self.welcomeLabel.alpha = 1
    }, completion: { (_) in
      UIView.animate(withDuration: 1, delay: 1, animations: {
        self.titleLabel.alpha = 1
      }, completion: { (_) in
        UIView.animate(withDuration: 1, delay: 1, animations: {
          self.personViewContainer.alpha = 1
        }, completion: { (_) in
          UIView.animate(withDuration: 1, delay: 1, animations: {
            self.startbutton.alpha = 1
          })
        })
      })
    })
  }
}

// MARK: - Setup Views and View Actions
extension OnBoardingViewController {
  private func setupView() {
    view.addSubview(welcomeLabel)
    welcomeLabel.anchor(top: view.safeAreaLayoutGuide.topAnchor, paddingTop: 49,
                        width: 250, height: 37, centerX: view.centerXAnchor)
    view.addSubview(titleLabel)
    titleLabel.anchor(top: welcomeLabel.safeAreaLayoutGuide.bottomAnchor, paddingTop: 8,
                      width: 330, height: 60, centerX: view.centerXAnchor)
    
    view.addSubview(personViewContainer)
    personViewContainer.anchor(width: 231, height: 602,
                               centerX: view.centerXAnchor, centerY: view.centerYAnchor)
    setupPersonView()
    view.addSubview(startbutton)
    startbutton.anchor(bottom: view.safeAreaLayoutGuide.bottomAnchor, paddingBottom: 108,
                       width: 341, height: 72,
                       centerX: view.centerXAnchor)
    startbutton.addTarget(self, action: #selector(OnboardButtonAction), for: .touchUpInside)
  }
  
  private func setupPersonView() {
    personViewContainer.addSubview(personHead)
    personViewContainer.addSubview(personBody)
    personViewContainer.addSubview(personRightHand)
    personViewContainer.addSubview(personLeftHand)
    personViewContainer.addSubview(personRightLeg)
    personViewContainer.addSubview(personLeftLeg)
    
    personHead.anchor(top: personViewContainer.topAnchor, paddingTop: 20,
                      bottom: nil, paddingBottom: 0,
                      left: personViewContainer.leftAnchor, paddingLeft: 71,
                      right: personViewContainer.rightAnchor, paddingRight: 71,
                      width: 89, height: 89,
                      centerX: nil, centerY: nil,
                      enableInsets: false)
    

    personBody.anchor(top: personHead.bottomAnchor, paddingTop: 8,
                      bottom: nil, paddingBottom: 0,
                      left: personLeftHand.rightAnchor, paddingLeft: 8,
                      right: nil, paddingRight: 0,
                      width: 95, height: 228,
                      centerX: nil, centerY: nil,
                      enableInsets: false)
    

    personRightHand.anchor(top: personViewContainer.topAnchor, paddingTop: 117,
                           bottom: personViewContainer.bottomAnchor, paddingBottom: 305,
                           left: personBody.rightAnchor, paddingLeft: 8,
                           right: personViewContainer.rightAnchor, paddingRight: 20,
                           width: 40, height: 180,
                           centerX: nil, centerY: nil,
                           enableInsets: false)
    

    personLeftHand.anchor(top: personViewContainer.topAnchor, paddingTop: 117,
                          bottom: personViewContainer.bottomAnchor, paddingBottom: 305,
                          left: personViewContainer.leftAnchor, paddingLeft: 20,
                          right: personBody.leftAnchor, paddingRight: 8,
                          width: 40, height: 180,
                          centerX: nil, centerY: nil,
                          enableInsets: false)
    

    personRightLeg.anchor(top: personBody.bottomAnchor, paddingTop: 8,
                          bottom: personViewContainer.bottomAnchor, paddingBottom: 20,
                          left: personLeftLeg.rightAnchor, paddingLeft: 17,
                          right: personViewContainer.rightAnchor, paddingRight: 68,
                          width: 39, height: 229,
                          centerX: nil, centerY: nil,
                          enableInsets: false)
    

    personLeftLeg.anchor(top: personBody.bottomAnchor, paddingTop: 8,
                         bottom: personViewContainer.bottomAnchor, paddingBottom: 20,
                         left: personViewContainer.leftAnchor, paddingLeft: 68,
                         right: nil, paddingRight:0,
                         width: 39, height: 229,
                         centerX: nil, centerY: nil,
                         enableInsets: false)
  }
  
  @objc private func OnboardButtonAction(sender: UIButton!) {
    self.navigateToIntroduction()
  }
  
  @objc private func navigateToIntroduction() {
    let introVC = IntroductionViewController()
    introVC.modalPresentationStyle = .fullScreen
    self.present(introVC, animated: true)
  }
}


