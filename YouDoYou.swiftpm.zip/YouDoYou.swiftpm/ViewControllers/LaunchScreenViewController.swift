//
//  File.swift
//  
//
//  Created by Hilmy Veradin on 20/04/22.
//

import Foundation
import UIKit

class LaunchScreeenViewController: UIViewController {
  
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .systemGray6
    DispatchQueue.main.asyncAfter(deadline: .now()) {
      let OnboardVC = OnBoardingViewController()
      OnboardVC.modalPresentationStyle = .fullScreen
      self.present(OnboardVC, animated: true)
    }
  }
  
}
