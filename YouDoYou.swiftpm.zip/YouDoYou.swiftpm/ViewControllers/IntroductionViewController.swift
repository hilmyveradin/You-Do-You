//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//

import Foundation
import UIKit

class IntroductionViewController: UIViewController {
  
  //MARK: - View Properties
  private var introContainer: UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 20.0
    return view
  }()
  
  private var introLabel : UILabel! = {
    let lbl = UILabel()
    lbl.numberOfLines = 0
    lbl.textAlignment = .center
    lbl.alpha = 0
    lbl.font = .systemFont(ofSize: 32)
    return lbl
  }()
  
  
  private var introButton : UIButton = {
    let btn = UIButton()
    btn.backgroundColor = .orange
    btn.setTitle("Lets Go!", for: .normal)
    btn.titleLabel?.font = UIFont.systemFont(ofSize: 30)
    btn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.8).cgColor
    btn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
    btn.layer.shadowOpacity = 1.0
    btn.layer.shadowRadius = 5
    btn.layer.cornerRadius = 15
    btn.layer.borderWidth = 1
    btn.layer.borderColor = UIColor.black.cgColor
    btn.alpha = 0
    return btn
  }()
  
  // MARK: - Attribute
  private var speech = Speech()
  
  //MARK: - Life Cycles
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .systemGray6
    setupView()
    animateElements()
  }
  //MARK: - Helpers
  
  // Animate Elements
  private func animateElements() {
    UIView.animate(withDuration: 1, delay: 0, animations: {
      self.animateCreatorText(text: Texts.IntroTexts.text1)
    }, completion: { (_) in
      UIView.animate(withDuration: 0.5, delay: 5, animations: {
        self.introLabel.alpha = 0
      }, completion: { (_) in
        UIView.animate(withDuration: 1, delay: 0, animations: {
          self.animateCreatorText(text: Texts.IntroTexts.text2)
        }, completion: { (_) in
          UIView.animate(withDuration: 0.5, delay: 4, animations: {
            self.introLabel.alpha = 0
          }, completion: { (_) in
            UIView.animate(withDuration: 1, delay: 0, animations: {
              self.introLabel.text = "\(Texts.IntroTexts.text3) 🤩"
              self.introLabel.alpha = 1
              self.speech.playerSpeak(phrase: Texts.IntroTexts.text3)
            }, completion: { (_) in
              UIView.animate(withDuration: 0.5, delay: 3, animations: {
                self.introLabel.alpha = 0
              }, completion: { (_) in
                UIView.animate(withDuration: 1, delay: 0, animations: {
                  self.introLabel.text = "\(Texts.IntroTexts.text4) 😞"
                  self.introLabel.alpha = 1
                  self.speech.playerSpeak(phrase: Texts.IntroTexts.text4)
                }, completion: {(_) in
                  UIView.animate(withDuration: 0.5, delay: 3, animations: {
                    self.introLabel.alpha = 0
                  }, completion: {(_) in
                    UIView.animate(withDuration: 1, delay: 0, animations: {
                      self.animateCreatorText(text: Texts.IntroTexts.text5)
                    }, completion: {(_) in
                      UIView.animate(withDuration: 0.5, delay: 4, animations: {
                        self.introLabel.alpha = 0
                      }, completion: {(_) in
                        UIView.animate(withDuration: 1, delay: 0, animations: {
                          self.animateCreatorText(text: Texts.IntroTexts.text6)
                        }, completion: {(_) in
                          UIView.animate(withDuration: 0.5, delay: 6, animations: {
                            self.introLabel.alpha = 0
                          }, completion: {(_) in
                            UIView.animate(withDuration: 1, delay: 0, animations: {
                              self.animateCreatorText(text: Texts.IntroTexts.text7)
                            }, completion: {(_) in
                              UIView.animate(withDuration: 0.5, delay: 4, animations: {
                                self.introLabel.alpha = 0
                              }, completion: { (_) in
                                UIView.animate(withDuration: 1, delay: 0, animations: {
                                  self.animateCreatorText(text: Texts.IntroTexts.text8)
                                }, completion: { (_) in
                                  UIView.animate(withDuration: 0.5, delay: 4, animations: {
                                    self.introLabel.alpha = 0
                                  }, completion: { (_) in
                                    UIView.animate(withDuration: 1, delay: 0, animations: {
                                      self.animateCreatorText(text: Texts.IntroTexts.text9)
                                    }, completion: { (_) in
                                      UIView.animate(withDuration: 0.5, delay: 4, animations: {
                                        self.introLabel.alpha = 0
                                      }, completion: { (_) in
                                        UIView.animate(withDuration: 1, delay: 0, animations: {
                                          self.animateCreatorText(text: Texts.IntroTexts.text10)
                                        }, completion: { (_) in
                                          UIView.animate(withDuration: 0.5, delay: 6, animations: {
                                            self.introLabel.alpha = 0
                                          }, completion: { (_) in
                                            UIView.animate(withDuration: 2, delay: 0, animations: {
                                              self.introLabel.text = "\(Texts.IntroTexts.finalText) 😆"
                                              self.introLabel.alpha = 1
                                              self.speech.creatorSpeak(phrase: Texts.IntroTexts.finalText)
                                            }, completion: { (_) in
                                              UIView.animate(withDuration: 0.5, delay: 1, animations: {
//                                                self.introButton.isHidden = false
                                                self.introButton.alpha = 1
                                              })
                                            })
                                          })
                                        })
                                      })
                                    })
                                  })
                                })
                              })
                            })
                          })
                        })
                      })
                    })
                  })
                })
              })
            })
          })
        })
      })
    })
  }
  
  private func animateCreatorText(text: String) {
    self.introLabel.text = text
    self.introLabel.alpha = 1
    self.speech.creatorSpeak(phrase: self.introLabel.text!)
  }
  
  private func animatePlayerText(text: String) {
    self.introLabel.text = text
    self.introLabel.alpha = 1
    self.speech.playerSpeak(phrase: self.introLabel.text!)
  }
}

//MARK: - Setup Views
extension IntroductionViewController {
  private func setupView() {
    view.addSubview(introContainer)
    introContainer.addSubview(introLabel)
    view.addSubview(introButton)
    
    introContainer.anchor(top: nil, paddingTop: 0,
                      bottom: nil, paddingBottom: 0,
                      left: nil, paddingLeft: 0,
                      right: nil, paddingRight: 0,
                      width: 700, height: 192,
                      centerX: view.centerXAnchor, centerY: view.centerYAnchor,
                      enableInsets: false)
    
    introLabel.anchor(top: introContainer.topAnchor, paddingTop: 24,
                      bottom: introContainer.bottomAnchor, paddingBottom: 24,
                      left: introContainer.leftAnchor, paddingLeft: 8,
                      right: introContainer.rightAnchor, paddingRight: 8,
                      width: 0, height: 0,
                      centerX: nil, centerY: nil,
                      enableInsets: false)
    
    introButton.anchor(top: introLabel.bottomAnchor, paddingTop: 40,
                       bottom: nil, paddingBottom: 0,
                       left: nil, paddingLeft: 0,
                       right: nil, paddingRight: 0,
                       width: 400, height: 69,
                       centerX: view.centerXAnchor, centerY: nil,
                       enableInsets: false)
    introButton.addTarget(self, action: #selector(introButtonAction), for: .touchUpInside)
  }
  
  @objc private func introButtonAction() {
    let DecisionVC = DecisionViewController()
    DecisionVC.modalPresentationStyle = .fullScreen
    self.present(DecisionVC, animated: true)
  }
}



