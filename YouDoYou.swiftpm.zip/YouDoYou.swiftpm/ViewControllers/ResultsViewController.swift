//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//

import Foundation
import UIKit

class ResultsViewController: UIViewController {
  //MARK: - Properties
  private var titleContainer: UIView = {
    let view = UIView()
    //    view.backgroundColor = .green
    view.alpha = 0
    return view
  }()
  
  private var personContainer: UIView = {
    let view = UIView()
    //    view.backgroundColor = .gray
    view.alpha = 0
    return view
  }()
  
  private var descriptionContainer: UIView = {
    let view = UIView()
    //    view.backgroundColor = .green
    view.alpha = 0
    return view
  }()
  
  private var titleLabel : UILabel! = {
    let lbl = UILabel()
    lbl.numberOfLines = 1
    lbl.textAlignment = .center
    lbl.font = .boldSystemFont(ofSize: 40)
    //    lbl.backgroundColor = .red
    lbl.text = "Voila! This is you!"
    return lbl
  }()
  
  private var personHead : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 73/2
    return view
  }()
  private var personBody  : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  private var personRightHand : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  private var personLeftHand : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    return view
  }()
  private var personRightLeg : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  private var personLeftLeg : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  
  private var descriptionLabel : UILabel! = {
    let lbl = UILabel()
    lbl.numberOfLines = 0
    lbl.textAlignment = .center
    lbl.font = .systemFont(ofSize: 28)
    //    lbl.backgroundColor = .red
    lbl.alpha = 0
    return lbl
  }()
  
  private var endButton : UIButton = {
    let btn = UIButton()
    btn.backgroundColor = .orange
    btn.setTitle("Got It. Will do! 😃", for: .normal)
    btn.titleLabel?.font = UIFont.systemFont(ofSize: 30)
    btn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.8).cgColor
    btn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
    btn.layer.borderWidth = 1
    btn.layer.shadowOpacity = 1.0
    btn.layer.shadowRadius = 5
    btn.layer.cornerRadius = 10
    btn.alpha = 0
    return btn
  }()
  
  private var speech = Speech()
  
  
  //MARK: - Life Cycles
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .systemGray5
    setupView()
    DispatchQueue.main.asyncAfter(deadline: .now(), execute: {
      self.initResultAnimation()
      DispatchQueue.main.asyncAfter(deadline: .now()+5, execute: {
        self.animateTexts()
      })
    })
    endButton.addTarget(self, action: #selector(resultToEnd), for: .touchUpInside)
  }
  //MARK: - Helpers
  @objc private func resultToEnd() {
    let endVC = EndViewController()
    endVC.modalPresentationStyle = .fullScreen
    self.present(endVC, animated: false)
  }
}

//MARK: - Setup Views
extension ResultsViewController {
  private func setupView() {
    view.addSubview(titleContainer)
    titleContainer.addSubview(titleLabel)
    view.addSubview(personContainer)
    view.addSubview(descriptionContainer)
    descriptionContainer.addSubview(descriptionLabel)
    view.addSubview(endButton)
    
    titleContainer.anchor(top: view.safeAreaLayoutGuide.topAnchor, paddingTop: 34,
                          bottom: nil, paddingBottom: 0,
                          left: view.safeAreaLayoutGuide.leftAnchor, paddingLeft: 209,
                          right: view.safeAreaLayoutGuide.rightAnchor, paddingRight: 209,
                          width: 350, height: 71,
                          centerX: nil, centerY: nil,
                          enableInsets: false)
    titleLabel.anchor(top: titleContainer.topAnchor, paddingTop: 8,
                      bottom: titleContainer.bottomAnchor, paddingBottom: 8,
                      left: titleContainer.leftAnchor, paddingLeft: 8,
                      right: titleContainer.rightAnchor, paddingRight: 8,
                      width: 0, height: 71,
                      centerX: nil, centerY: nil,
                      enableInsets: false)
    
    personContainer.anchor(top: nil, paddingTop: 0,
                           bottom: nil, paddingBottom: 0,
                           left: nil, paddingLeft: 0,
                           right: nil, paddingRight: 0,
                           width: 191, height: 525,
                           centerX: view.centerXAnchor, centerY: view.centerYAnchor,
                           enableInsets: false)
    setupPersonView()
    descriptionContainer.anchor(top: personContainer.bottomAnchor, paddingTop: 18,
                                bottom: endButton.topAnchor, paddingBottom: 16,
                                left: nil, paddingLeft: 0,
                                right: nil, paddingRight: 0,
                                width: 564, height: 0,
                                centerX: view.centerXAnchor, centerY: nil,
                                enableInsets: false)
    descriptionLabel.anchor(top: descriptionContainer.topAnchor, paddingTop: 8,
                            bottom: descriptionContainer.bottomAnchor, paddingBottom: 8,
                            left: descriptionContainer.leftAnchor, paddingLeft: 8,
                            right: descriptionContainer.rightAnchor, paddingRight: 8,
                            width: 0, height: 0,
                            centerX: nil, centerY: nil,
                            enableInsets: false)
    
    endButton.anchor(top: nil, paddingTop: 0,
                     bottom: view.safeAreaLayoutGuide.bottomAnchor, paddingBottom: 44,
                     left: nil, paddingLeft: 0,
                     right: nil, paddingRight: 0,
                     width: 400, height: 60,
                     centerX: view.centerXAnchor, centerY: nil,
                     enableInsets: false)
  }
  
  private func setupPersonView() {
    let personColor = UIColor(red: CGFloat(saveNumber1/10)/255.0,
                              green: CGFloat(saveNumber2/10)/255.0,
                              blue: CGFloat(saveNumber3/10)/255.0,
                              alpha: 1)
    
    personContainer.addSubview(personHead)
    personContainer.addSubview(personBody)
    personContainer.addSubview(personLeftHand)
    personContainer.addSubview(personRightHand)
    personContainer.addSubview(personLeftLeg)
    personContainer.addSubview(personRightLeg)
    
    personHead.anchor(top: personContainer.topAnchor, paddingTop: 20,
                      bottom: nil, paddingBottom: 0,
                      left: nil, paddingLeft: 0,
                      right: nil, paddingRight: 0,
                      width: 73, height: 73,
                      centerX: personContainer.centerXAnchor, centerY: nil,
                      enableInsets: false)
    personBody.anchor(top: personHead.bottomAnchor, paddingTop: 8,
                      bottom: nil, paddingBottom: 0,
                      left: nil, paddingLeft: 0,
                      right: nil, paddingRight: 0,
                      width: 79, height: 190,
                      centerX: personContainer.centerXAnchor, centerY: nil,
                      enableInsets: false)
    personLeftHand.anchor(top: personContainer.topAnchor, paddingTop: 101,
                          bottom: nil, paddingBottom: 0,
                          left: nil, paddingLeft: 0,
                          right: personBody.leftAnchor, paddingRight: 8,
                          width: 28, height: 129,
                          centerX: nil, centerY: nil,
                          enableInsets: false)
    personRightHand.anchor(top: personContainer.topAnchor, paddingTop: 101,
                           bottom: nil, paddingBottom: 0,
                           left: personBody.rightAnchor, paddingLeft: 8,
                           right: nil, paddingRight: 0,
                           width: 28, height: 129,
                           centerX: nil, centerY: nil,
                           enableInsets: false)
    personLeftLeg.anchor(top: personBody.bottomAnchor, paddingTop: 8,
                         bottom: nil, paddingBottom: 0,
                         left: personContainer.leftAnchor, paddingLeft: 55,
                         right: nil, paddingRight: 0,
                         width: 35, height: 206,
                         centerX: nil, centerY: nil,
                         enableInsets: false)
    personRightLeg.anchor(top: personBody.bottomAnchor, paddingTop: 8,
                          bottom: nil, paddingBottom: 0,
                          left: nil, paddingLeft: 0,
                          right: personContainer.rightAnchor, paddingRight: 55,
                          width: 35, height: 206,
                          centerX: nil, centerY: nil,
                          enableInsets: false)
    
    personHead.backgroundColor = personColor
    personBody.backgroundColor = personColor
    personLeftHand.backgroundColor = personColor
    personRightHand.backgroundColor = personColor
    personLeftLeg.backgroundColor = personColor
    personRightLeg.backgroundColor = personColor
    
  }
  
  private func setPersonColor() {
    
  }
}

//MARK: - Animate View
extension ResultsViewController {
  private func initResultAnimation() {
    UIView.animate(withDuration: 1, delay: 0, animations: {
      self.titleContainer.alpha = 1
    }, completion: { (_) in
      UIView.animate(withDuration: 3, delay: 1, animations: {
        self.personContainer.alpha = 1
      }, completion: { (_) in
        UIView.animate(withDuration: 1, delay: 1, animations: {
          self.descriptionContainer.alpha = 1
          self.descriptionLabel.alpha = 1
        })
      })
    })
  }
  
  private func animateTexts() {
    UIView.animate(withDuration: 1, delay: 0, animations: {
      self.animateCreatorText(text: Texts.ResultTexts.resultText1)
    }, completion: {(_) in
      UIView.animate(withDuration: 1, delay: 5, animations: {
        self.descriptionLabel.alpha = 0
      }, completion: { (_) in
        UIView.animate(withDuration: 0.5, delay: 0, animations: {
          self.animateCreatorText(text: Texts.ResultTexts.resultText2)
        }, completion: { (_) in
          UIView.animate(withDuration: 1, delay: 4, animations: {
            self.descriptionLabel.alpha = 0
          }, completion: { (_) in
            UIView.animate(withDuration: 0.5, delay: 0, animations: {
              self.animateCreatorText(text: Texts.ResultTexts.resultText3)
            }, completion: { (_) in
              UIView.animate(withDuration: 1, delay: 2, animations: {
                self.descriptionLabel.alpha = 0
              }, completion: {(_) in
                UIView.animate(withDuration: 0.5, delay: 0, animations: {
                  self.animateCreatorText(text: Texts.ResultTexts.resultText4)
                }, completion: {(_) in
                  UIView.animate(withDuration: 1, delay: 5, animations: {
                    self.descriptionLabel.alpha = 0
                  }, completion: {(_) in
                    UIView.animate(withDuration: 0.5, delay: 0, animations: {
                      self.animateCreatorText(text: Texts.ResultTexts.resultText5)
                    }, completion: {(_) in
                      UIView.animate(withDuration: 0.5, delay: 5, animations: {
                        self.descriptionLabel.alpha = 0
                      }, completion: {(_) in
                        UIView.animate(withDuration: 1, delay: 0, animations: {
                          self.descriptionLabel.text = "\(Texts.ResultTexts.resultText6) 🤔"
                          self.descriptionLabel.alpha = 1
                          self.speech.playerSpeak(phrase: Texts.ResultTexts.resultText6)
                        }, completion: {(_) in
                          UIView.animate(withDuration: 0.5, delay: 4, animations: {
                            self.descriptionLabel.alpha = 0
                          }, completion: {(_) in
                            UIView.animate(withDuration: 1, delay: 0, animations: {
                              self.animateCreatorText(text: Texts.ResultTexts.resultText7)
                            }, completion: {(_) in
                              UIView.animate(withDuration: 0.5, delay: 4, animations: {
                                self.descriptionLabel.alpha = 0
                              }, completion: { (_) in
                                UIView.animate(withDuration: 1, delay: 0, animations: {
                                  self.animateCreatorText(text: Texts.ResultTexts.resultText8)
                                }, completion: {(_) in
                                  UIView.animate(withDuration: 0.5, delay: 3, animations: {
                                    self.descriptionLabel.alpha = 0
                                  }, completion: {(_) in
                                    UIView.animate(withDuration: 1, delay: 0, animations: {
                                      self.animateCreatorText(text: Texts.ResultTexts.resultText9)
                                    }, completion: {(_) in
                                      UIView.animate(withDuration: 0.5, delay: 3, animations: {
                                        self.descriptionLabel.alpha = 0
                                      }, completion: { (_) in
                                        UIView.animate(withDuration: 1, delay: 0, animations: {
                                          self.animateCreatorText(text: Texts.ResultTexts.resultText10)
                                        }, completion: { (_) in
                                          UIView.animate(withDuration: 0.5, delay: 2, animations: {
                                            self.descriptionLabel.alpha = 0
                                          }, completion: { (_) in
                                            UIView.animate(withDuration: 1, delay: 0, animations: {
                                              self.animateCreatorText(text: Texts.ResultTexts.resultText11)
                                            }, completion: {(_) in
                                              UIView.animate(withDuration: 0.5, delay: 2, animations: {
                                                self.descriptionLabel.alpha = 0
                                              }, completion: {(_) in
                                                UIView.animate(withDuration: 1, delay: 0, animations: {
                                                  self.animateCreatorText(text: Texts.ResultTexts.resultText12)
                                                }, completion: { (_) in
                                                  UIView.animate(withDuration: 0.5, delay: 2, animations: {
                                                    self.descriptionLabel.alpha = 0
                                                  }, completion: { (_) in
                                                    UIView.animate(withDuration: 1, delay: 0, animations: {
                                                      self.descriptionLabel.text = "\(Texts.ResultTexts.resultText13)"
                                                      self.descriptionLabel.alpha = 1
                                                      self.speech.creatorSpeak(phrase: Texts.ResultTexts.resultText13)
                                                    }, completion: { (_) in
                                                      UIView.animate(withDuration: 0.5, delay: 2, animations: {
                                                        self.descriptionContainer.alpha = 0
                                                        self.descriptionLabel.alpha = 0
                                                        self.titleContainer.alpha = 0
                                                        self.personContainer.alpha = 0
                                                      }, completion: {(_) in
                                                        UIView.animate(withDuration: 1, delay: 0, animations: {
                                                          
                                                          //                                                          self.endButton.alpha = 1
                                                          //                                                          self.descriptionLabel.text = "\(Texts.ResultTexts.resultText14) 👊"
                                                          //                                                          self.descriptionLabel.alpha = 1
                                                          //                                                          self.speech.creatorSpeak(phrase: Texts.ResultTexts.resultText14)
                                                        }, completion: {(_) in
                                                          UIView.animate(withDuration: 0.5, delay: 1, animations: {
                                                            self.resultToEnd()
                                                          })
                                                        })
                                                      })
                                                    })
                                                  })
                                                })
                                              })
                                            })
                                          })
                                        })
                                      })
                                    })
                                  })
                                })
                              })
                            })
                          })
                        })
                      })
                    })
                  })
                })
              })
            })
          })
        })
      })
    })
  }
  
  private func animateCreatorText(text: String) {
    self.descriptionLabel.text = text
    self.descriptionLabel.alpha = 1
    self.speech.creatorSpeak(phrase: self.descriptionLabel.text!)
  }
}
