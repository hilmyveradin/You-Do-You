//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//

import Foundation
import UIKit

class LoadingViewController: UIViewController {
  //MARK: - Properties
  private var loadingContainer: UIView = {
    let view = UIView()
//    view.backgroundColor = .green
    return view
  }()
  
  private var loadingLabel : UILabel! = {
    let lbl = UILabel()
    lbl.numberOfLines = 1
    lbl.textAlignment = .center
    lbl.font = .systemFont(ofSize: 30)
    lbl.text = "Generating you"
    return lbl
  }()
  
  private var loadingButton: UIButton! = {
    let btn = UIButton()
    btn.backgroundColor = .orange
    btn.setTitle("Let Me See!", for: .normal)
    btn.titleLabel?.font = UIFont.systemFont(ofSize: 30)
    btn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.8).cgColor
    btn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
    btn.layer.borderWidth = 1
    btn.layer.borderColor = UIColor.black.cgColor
    btn.layer.shadowOpacity = 1.0
    btn.layer.shadowRadius = 5
    btn.layer.cornerRadius = 5
    btn.alpha = 0
    return btn
  }()
  
  //MARK: - Life Cycles
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .systemGray6
    setupView()
    DispatchQueue.main.asyncAfter(deadline: .now()+1, execute: {
      self.loadingLabel.text = "Generating you."
      DispatchQueue.main.asyncAfter(deadline: .now()+1, execute: {
        self.loadingLabel.text = "Generating you.."
        DispatchQueue.main.asyncAfter(deadline: .now()+1, execute: {
          UIView.animate(withDuration: 1, delay: 0, animations: {
            self.loadingLabel.alpha = 0
          })
          DispatchQueue.main.asyncAfter(deadline: .now()+1, execute: {
                      let resultVC = ResultsViewController()
            resultVC.modalPresentationStyle = .fullScreen
            self.present(resultVC, animated: false)
          })
        })
      })
    })
    loadingButton.addTarget(self, action: #selector(loadingToResult), for: .touchUpInside)
  }
  //MARK: - Helpers
  
  @objc private func loadingToResult() {
    let resultVC = ResultsViewController()
    resultVC.modalPresentationStyle = .fullScreen
    self.present(resultVC, animated: true)
  }
  
}

//MARK: - Setup Views
extension LoadingViewController {
  private func setupView() {
    view.addSubview(loadingLabel)
    view.addSubview(loadingButton)
    loadingLabel.anchor(top: nil, paddingTop: 0,
                            bottom: nil, paddingBottom: 0,
                            left: view.safeAreaLayoutGuide.leftAnchor, paddingLeft: 64,
                            right: view.safeAreaLayoutGuide.rightAnchor, paddingRight: 64,
                            width: 0, height: 80,
                            centerX: view.centerXAnchor, centerY: view.centerYAnchor,
                            enableInsets: false)
    loadingButton.anchor(top: loadingLabel.bottomAnchor, paddingTop: 26,
                        bottom: nil, paddingBottom: 0,
                        left: nil, paddingLeft: 0,
                        right: nil, paddingRight: 0,
                        width: 300, height: 60,
                        centerX: view.centerXAnchor, centerY: nil,
                        enableInsets: false)
    
  }
}

//MARK: - Animate Views
extension LoadingViewController {
  private func animateLoading() {
    UIView.animate(withDuration: 1, delay: 0.5, animations: {
      self.loadingLabel.alpha = 0
    }, completion: { (_) in
      UIView.animate(withDuration: 1, delay: 0.5, animations: {
        self.loadingLabel.alpha = 1
        self.loadingLabel.text = "Your person canvas is ready!"
      }, completion: { (_) in
        UIView.animate(withDuration: 1, delay: 1, animations: {
          self.loadingButton.alpha = 1
        })
      })
      
    })
  }
}

