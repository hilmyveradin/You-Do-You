//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//

import Foundation
import UIKit

class DecisionViewController: UIViewController {
  //MARK: - Views Properties
  private var mainTitleContainer: UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 3
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 15
    view.alpha = 0
    return view
  }()
  
  private var decisionContainer: UIView = {
    let view = UIView()
    view.alpha = 0
    return view
  }()
  
  private var leftContainer: UIView = {
    let view = UIView()
    //    view.backgroundColor = .blue
    view.backgroundColor = .white
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.borderWidth = 3.0
    view.layer.cornerRadius = 4.0
    view.alpha = 0
    return view
  }()
  
  private var rightContainer: UIView = {
    let view = UIView()
    //    view.backgroundColor = .blue
    view.backgroundColor = .white
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.borderWidth = 3.0
    view.layer.cornerRadius = 4.0
    view.alpha = 0
    return view
  }()
  
  private var leftColorBar: UIView = {
    let view = UIView()
    //    view.backgroundColor = .blue
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.borderWidth = 1.0
    view.layer.cornerRadius = 4.0
    view.alpha = 0
    return view
  }()
  
  private var RightColorBar: UIView = {
    let view = UIView()
    //    view.backgroundColor = .blue
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.borderWidth = 1.0
    view.layer.cornerRadius = 4.0
    view.alpha = 0
    return view
  }()
  
  private var titleLabel : UILabel! = {
    let lbl = UILabel()
    lbl.text = "Select one of the choices!\nPick left or right!"
    lbl.numberOfLines = 2
    lbl.textAlignment = .center
    lbl.font = .systemFont(ofSize: 30)
    return lbl
  }()
  
  private var leftLabel : UILabel! = {
    let lbl = UILabel()
    
    lbl.numberOfLines = 2
    lbl.textAlignment = .center
    lbl.font = .systemFont(ofSize: 22)
    lbl.textColor = .black
    lbl.shadowColor = .black
    lbl.isHighlighted = true
    lbl.highlightedTextColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
    lbl.alpha = 1
    return lbl
  }()
  
  private var rightLabel : UILabel! = {
    let lbl = UILabel()
    lbl.backgroundColor = .white
    lbl.numberOfLines = 2
    lbl.textAlignment = .center
    lbl.font = .systemFont(ofSize: 22)
    lbl.textColor = .black
    lbl.shadowColor = .black
    lbl.isHighlighted = true
    lbl.highlightedTextColor = UIColor(red: 0, green:0, blue: 0, alpha: 1)
    lbl.alpha = 1
    return lbl
  }()
  
  private var leftButton : UIButton = {
    let btn = UIButton()
    btn.backgroundColor = .orange
    btn.setTitle("I Choose This", for: .normal)
    btn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
    btn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.8).cgColor
    btn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
    btn.layer.shadowOpacity = 1.0
    btn.layer.shadowRadius = 5
    btn.layer.borderWidth = 1
    btn.layer.borderColor = UIColor.black.cgColor
    btn.layer.cornerRadius = 5
    btn.alpha = 0
    return btn
  }()
  
  private var rightButton : UIButton = {
    let btn = UIButton()
    btn.backgroundColor = .orange
    btn.setTitle("I Choose This!", for: .normal)
    btn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
    btn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.8).cgColor
    btn.layer.shadowOffset = CGSize(width: 0.0, height: 3.0)
    btn.layer.shadowOpacity = 1.0
    btn.layer.shadowRadius = 5
    btn.layer.borderWidth = 1
    btn.layer.borderColor = UIColor.black.cgColor
    btn.layer.cornerRadius = 5
    btn.alpha = 0
    return btn
  }()
  
  private var personViewContainer : UIView = {
    let view = UIView()
    //    view.backgroundColor = .gray
    view.alpha = 0
    return view
  }()
  private var personHead : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 73/2
    return view
  }()
  private var personBody  : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  private var personRightHand : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  private var personLeftHand : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  private var personRightLeg : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  private var personLeftLeg : UIView = {
    let view = UIView()
    view.backgroundColor = .white
    view.layer.borderWidth = 2
    view.layer.borderColor = UIColor.black.cgColor
    view.layer.cornerRadius = 5
    view.layer.cornerRadius = 5
    return view
  }()
  
  //MARK: - Functional Properties
  
  var rightBarColor: UIColor!
  var leftBarColor: UIColor!
  
  var darkRandom1 = Int.random(in: 50...100)
  var darkRandom2 = Int.random(in: 50...100)
  var darkRandom3 = Int.random(in: 50...100)
  
  var lightRandom1 = Int.random(in: 220...255)
  var lightRandom2 = Int.random(in: 220...255)
  var lightRandom3 = Int.random(in: 220...255)
  
  var tempRandom1: Int = 255
  var tempRandom2: Int = 255
  var tempRandom3: Int = 255
  
  var count = 0
  
  //MARK: - Life Cycles
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = .systemGray6
    setupView()
    DispatchQueue.main.asyncAfter(deadline: .now(), execute: {
      self.initDecisionAnimation()
      DispatchQueue.main.asyncAfter(deadline: .now()+3, execute: {
        self.modifyText()
      })
    })
    leftButton.addTarget(self, action: #selector(countColorLeft), for: .touchUpInside)
    rightButton.addTarget(self, action: #selector(countColorRight), for: .touchUpInside)
  }
  
  //MARK: - Helpers
  @objc func countColorLeft() {
    saveNumber1 += CGFloat(darkRandom1)
    saveNumber2 += CGFloat(darkRandom2)
    saveNumber3 += CGFloat(darkRandom3)
    print("saveNumber increased")
    personColorLeft()
    generateNumberAndView()
  }
  
  @objc func countColorRight() {
    saveNumber1 += CGFloat(lightRandom1)
    saveNumber2 += CGFloat(lightRandom2)
    saveNumber3 += CGFloat(lightRandom3)
    print("saveNumber increased")
    personColorRight()
    generateNumberAndView()
  }
  
  func generateNumberAndView() {
    count += 1
    if count < 10 {
      randomRightNumber()
      randomLeftNumber()
      rightBarColor = UIColor(red: CGFloat(lightRandom1)/255.0,
                              green: CGFloat(lightRandom2)/255.0,
                              blue: CGFloat(lightRandom3)/255.0,
                              alpha: 1)
      leftBarColor = UIColor(red: CGFloat(darkRandom1)/255.0,
                             green: CGFloat(darkRandom2)/255.0,
                             blue: CGFloat(darkRandom3)/255.0,
                             alpha: 1)
      modifyText()
      setupView()
      
    } else {
      self.leftButton.isHidden = true
      self.rightButton.isHidden = true
      print("------------------ FINAL NUMBER ----------------------")
      
      let LoadingVC = LoadingViewController()
      LoadingVC.modalPresentationStyle = .fullScreen
      self.present(LoadingVC, animated: true)
    }
  }
  
  func randomLeftNumber() {
    darkRandom1 = Int.random(in: 50...100)
    darkRandom2 = Int.random(in: 50...100)
    darkRandom3 = Int.random(in: 50...100)
    leftEmptyColor()
  }
  
  func randomRightNumber() {
    lightRandom1 = Int.random(in: 220...255)
    lightRandom2 = Int.random(in: 220...255)
    lightRandom3 = Int.random(in: 220...255)
  }
  
  func leftEmptyColor() {
    let random = Int.random(in: 0...6)
    switch random {
    case 0:
      darkRandom1 = 0
    case 1:
      darkRandom2 = 0
    case 2:
      darkRandom3 = 0
    case 3:
      darkRandom1 = 0
      darkRandom2 = 0
    case 4:
      darkRandom1 = 0
      darkRandom3 = 0
    case 5:
      darkRandom2 = 0
      darkRandom3 = 0
    default:
      print("default")
    }
  }
  
  func rightEmptyColor() {
    let random = Int.random(in: 0...6)
    switch random {
    case 0:
      lightRandom1 = 0
    case 1:
      lightRandom2 = 0
    case 2:
      lightRandom3 = 0
    case 3:
      lightRandom1 = 0
      lightRandom2 = 0
    case 4:
      lightRandom1 = 0
      lightRandom3 = 0
    case 5:
      lightRandom2 = 0
      lightRandom3 = 0
    default:
      print("default")
    }
  }
  
  private func personColorRight() {
    self.personHead.backgroundColor = rightBarColor
    self.personBody.backgroundColor = rightBarColor
    self.personLeftHand.backgroundColor = rightBarColor
    self.personRightHand.backgroundColor = rightBarColor
    self.personLeftLeg.backgroundColor = rightBarColor
    self.personRightLeg.backgroundColor = rightBarColor
    
  }
  
  private func personColorLeft() {
    self.personHead.backgroundColor = leftBarColor
    self.personBody.backgroundColor = leftBarColor
    self.personLeftHand.backgroundColor = leftBarColor
    self.personRightHand.backgroundColor = leftBarColor
    self.personLeftLeg.backgroundColor = leftBarColor
    self.personRightLeg.backgroundColor = leftBarColor
  }
}

//MARK: - Setup Views
extension DecisionViewController {
  private func setupView() {
    rightBarColor = UIColor(red: CGFloat(lightRandom1)/255.0,
                            green: CGFloat(lightRandom2)/255.0,
                            blue: CGFloat(lightRandom3)/255.0,
                            alpha: 1)
    leftBarColor = UIColor(red: CGFloat(darkRandom1)/255.0,
                           green: CGFloat(darkRandom2)/255.0,
                           blue: CGFloat(darkRandom3)/255.0,
                           alpha: 1)
    view.addSubview(mainTitleContainer)
    mainTitleContainer.addSubview(titleLabel)
    
    view.addSubview(leftContainer)
    RightColorBar.backgroundColor = rightBarColor
    leftContainer.addSubview(leftLabel)
    view.addSubview(leftColorBar)
    view.addSubview(leftButton)
    
    view.addSubview(rightContainer)
    rightContainer.addSubview(rightLabel)
    view.addSubview(RightColorBar)
    leftColorBar.backgroundColor = leftBarColor
    view.addSubview(rightButton)
    
    view.addSubview(personViewContainer)
    
    mainTitleContainer.anchor(top: view.safeAreaLayoutGuide.topAnchor, paddingTop: 48,
                              bottom: nil, paddingBottom: 0,
                              left: nil, paddingLeft: 0,
                              right: nil, paddingRight: 0,
                              width: 600, height: 128,
                              centerX: view.centerXAnchor, centerY: nil,
                              enableInsets: false)
    titleLabel.anchor(top: mainTitleContainer.topAnchor, paddingTop: 8,
                      bottom: mainTitleContainer.bottomAnchor, paddingBottom: 8,
                      left: mainTitleContainer.leftAnchor, paddingLeft: 8,
                      right: mainTitleContainer.rightAnchor, paddingRight: 8,
                      width: 0, height: 0,
                      centerX: nil, centerY: nil,
                      enableInsets: false)
    
    leftContainer.anchor(top: mainTitleContainer.bottomAnchor, paddingTop: 27,
                         bottom: nil, paddingBottom: 0,
                         left: view.safeAreaLayoutGuide.leftAnchor, paddingLeft: 117,
                         right: nil, paddingRight: 0,
                         width: 248, height: 82,
                         centerX: nil, centerY: nil,
                         enableInsets: false)
    leftLabel.anchor(top: leftContainer.topAnchor, paddingTop: 8,
                     bottom: leftContainer.bottomAnchor, paddingBottom: 8,
                     left: leftContainer.leftAnchor, paddingLeft: 8,
                     right: leftContainer.rightAnchor, paddingRight: 8,
                     width: 232, height: 66,
                     centerX: nil, centerY: nil,
                     enableInsets: false)
    leftColorBar.anchor(top: leftContainer.bottomAnchor, paddingTop: 5,
                        bottom: nil, paddingBottom: 0,
                        left: view.safeAreaLayoutGuide.leftAnchor, paddingLeft: 117,
                        right: nil, paddingRight: 0,
                        width: 248, height: 15,
                        centerX: nil, centerY: nil,
                        enableInsets: false)
    leftButton.anchor(top: leftColorBar.bottomAnchor, paddingTop: 10,
                      bottom: nil, paddingBottom: 0,
                      left: view.safeAreaLayoutGuide.leftAnchor, paddingLeft: 117,
                      right: nil, paddingRight: 0,
                      width: 248, height: 47,
                      centerX: nil, centerY: nil,
                      enableInsets: false)
    
    rightContainer.anchor(top: mainTitleContainer.bottomAnchor, paddingTop: 27,
                          bottom: nil, paddingBottom: 0,
                          left: nil, paddingLeft: 0,
                          right: view.safeAreaLayoutGuide.rightAnchor, paddingRight: 117,
                          width: 248, height: 82,
                          centerX: nil, centerY: nil,
                          enableInsets: false)
    rightLabel.anchor(top: rightContainer.topAnchor, paddingTop: 8,
                      bottom: rightContainer.bottomAnchor, paddingBottom: 8,
                      left: rightContainer.leftAnchor, paddingLeft: 8,
                      right: rightContainer.rightAnchor, paddingRight: 8,
                      width: 232, height: 66,
                      centerX: nil, centerY: nil,
                      enableInsets: false)
    RightColorBar.anchor(top: rightContainer.bottomAnchor, paddingTop: 5,
                         bottom: nil, paddingBottom: 0,
                         left: nil, paddingLeft: 0,
                         right: view.safeAreaLayoutGuide.rightAnchor, paddingRight: 117,
                         width: 248, height: 15,
                         centerX: nil, centerY: nil,
                         enableInsets: false)
    rightButton.anchor(top: RightColorBar.bottomAnchor, paddingTop: 10,
                       bottom: nil, paddingBottom: 0,
                       left: nil, paddingLeft: 0,
                       right: view.safeAreaLayoutGuide.rightAnchor, paddingRight: 117,
                       width: 248, height: 47,
                       centerX: nil, centerY: nil,
                       enableInsets: false)
    
    personViewContainer.anchor(top: nil, paddingTop: 0,
                               bottom: view.safeAreaLayoutGuide.bottomAnchor, paddingBottom: 34,
                               left: nil, paddingLeft: 0,
                               right: nil, paddingRight: 0,
                               width: 191, height: 525,
                               centerX: view.centerXAnchor, centerY: nil,
                               enableInsets: false)
    setupPersonView()
  }
  
  private func setupPersonView() {
    
    personViewContainer.addSubview(personHead)
    personViewContainer.addSubview(personBody)
    personViewContainer.addSubview(personLeftHand)
    personViewContainer.addSubview(personRightHand)
    personViewContainer.addSubview(personLeftLeg)
    personViewContainer.addSubview(personRightLeg)
    
    personHead.anchor(top: personViewContainer.topAnchor, paddingTop: 20,
                      bottom: nil, paddingBottom: 0,
                      left: nil, paddingLeft: 0,
                      right: nil, paddingRight: 0,
                      width: 73, height: 73,
                      centerX: personViewContainer.centerXAnchor, centerY: nil,
                      enableInsets: false)
    personBody.anchor(top: personHead.bottomAnchor, paddingTop: 8,
                      bottom: nil, paddingBottom: 0,
                      left: nil, paddingLeft: 0,
                      right: nil, paddingRight: 0,
                      width: 79, height: 190,
                      centerX: personViewContainer.centerXAnchor, centerY: nil,
                      enableInsets: false)
    personLeftHand.anchor(top: personViewContainer.topAnchor, paddingTop: 101,
                          bottom: nil, paddingBottom: 0,
                          left: nil, paddingLeft: 0,
                          right: personBody.leftAnchor, paddingRight: 8,
                          width: 28, height: 129,
                          centerX: nil, centerY: nil,
                          enableInsets: false)
    personRightHand.anchor(top: personViewContainer.topAnchor, paddingTop: 101,
                           bottom: nil, paddingBottom: 0,
                           left: personBody.rightAnchor, paddingLeft: 8,
                           right: nil, paddingRight: 0,
                           width: 28, height: 129,
                           centerX: nil, centerY: nil,
                           enableInsets: false)
    personLeftLeg.anchor(top: personBody.bottomAnchor, paddingTop: 8,
                         bottom: nil, paddingBottom: 0,
                         left: personViewContainer.leftAnchor, paddingLeft: 55,
                         right: nil, paddingRight: 0,
                         width: 35, height: 206,
                         centerX: nil, centerY: nil,
                         enableInsets: false)
    personRightLeg.anchor(top: personBody.bottomAnchor, paddingTop: 8,
                          bottom: nil, paddingBottom: 0,
                          left: nil, paddingLeft: 0,
                          right: personViewContainer.rightAnchor, paddingRight: 55,
                          width: 35, height: 206,
                          centerX: nil, centerY: nil,
                          enableInsets: false)
    
  }
}

// MARK: - Animate View
extension DecisionViewController {
  func modifyText() {
    
    self.leftContainer.alpha = 0
    self.rightContainer.alpha = 0
    self.leftColorBar.alpha = 0
    self.RightColorBar.alpha = 0
    self.leftButton.alpha = 0
    self.rightButton.alpha = 0

    
    UIView.animate(withDuration: 1, delay: 0, animations: {
      self.leftContainer.alpha = 1
      self.rightContainer.alpha = 1
      self.leftLabel.text = Texts.DecisionTexts.leftChoices[self.count]
      self.rightLabel.text = Texts.DecisionTexts.rightChoices[self.count]
      self.leftColorBar.alpha = 1
      self.RightColorBar.alpha = 1
      self.personHead.backgroundColor = .white
      self.personBody.backgroundColor = .white
      self.personLeftHand.backgroundColor = .white
      self.personRightHand.backgroundColor = .white
      self.personLeftLeg.backgroundColor = .white
      self.personRightLeg.backgroundColor = .white
    }, completion: { (_) in
      UIView.animate(withDuration: 1, delay: 0, animations: {
        self.rightButton.alpha = 1
        self.leftButton.alpha = 1
      }, completion: { (_) in
        UIView.animate(withDuration: 1, delay: 0, animations: {
        })
      })
    })
  }
  
  private func initDecisionAnimation() {
    UIView.animate(withDuration: 1, delay: 0, animations: {
      self.personViewContainer.alpha = 1
    }, completion: { (_) in
      UIView.animate(withDuration: 1, delay: 0, animations: {
        self.mainTitleContainer.alpha = 1
      })
    })
  }
}
