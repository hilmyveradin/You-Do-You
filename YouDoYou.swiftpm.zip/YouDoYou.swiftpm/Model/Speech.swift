//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//

import Foundation
import AVFoundation

public class Speech {
  public let synthesizer = AVSpeechSynthesizer()
  
  public func creatorSpeak(phrase: String) {
    DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
      if !phrase.isEmpty {
        self.synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: phrase)
        let voice = AVSpeechSynthesisVoice(identifier: "com.apple.ttsbundle.Daniel-compact")
        utterance.voice = voice
        utterance.rate = 0.47
        utterance.pitchMultiplier = 1.8
        utterance.volume = 1
        self.synthesizer.speak(utterance)
      }
    })
  }
  
  public func playerSpeak(phrase: String) {
    DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
      if !phrase.isEmpty {
        self.synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: phrase)
        utterance.rate = 0.47
        utterance.volume = 1
        self.synthesizer.speak(utterance)
      }
    })
  }
}
