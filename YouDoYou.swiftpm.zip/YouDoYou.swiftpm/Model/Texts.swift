//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//
import Foundation

// MARK: - Intro Texts
struct Texts {
  struct Emoji {
    static let creator = "👱"
    static let player = "👤"
  }
  
  struct IntroTexts {
    static let text1 = """
    Have you ever felt like you made an
    excellent decisions in your life?
    """
    
    static let text2 = """
    On the contrary, have you
    ever regretted something that you did?
    """
    
    static let text3 = """
    "Oh, I'm so grateful I did that!!!"
    """
    
    static let text4 = """
        "If only I knew… I shouldn't have done that…."
    """
    
    static let text5 = """
    Every decision that we took
    made us who we are today.
    """
    
    static let text6 = """
    In this Swift Student Challenge 2022.
    I want to take you to your previous self,
    """
    
    static let text7 = """
    And see how your decisions
    shaped you into who you are today!
    """
    
    static let text8 = """
    Your previous self is described
    with an empty person canvas.
    """
    
    static let text9 = """
      And your decisions will
      be symbolized by various colors.
    """
    
    static let text10 = """
    By the end of this playground, you'll see the final person,
    you-- embedded with your chosen colors!
    """
    
    static let finalText = "Let's get started, shall we?"
  }
}

// MARK: - Decision Texts
extension Texts {
  struct DecisionTexts {
    
    static let choice1L = "Get straight A’s only on the things you like"
    static let choice2L = "Spend money on vacation"
    static let choice3L = "Have a few friends"
    static let choice4L = "Going out with friends"
    static let choice5L = "Stay up late"
    static let choice6L = "Buy an expensive food"
    static let choice7L = "Online games"
    static let choice8L = "Read fiction books"
    static let choice9L = "Maximalism"
    static let choice10L = "Animal based food"
    static let leftChoices = [choice1L,choice2L,choice3L,choice4L,choice5L,choice6L,choice7L,choice8L,choice9L,choice10L]
    
    static let choice1R = "Get straight A’s in every class"
    static let choice2R = "Spend money on an investment"
    static let choice3R = "Have a lot of friends"
    static let choice4R = "Study at home"
    static let choice5R = "Wake up early"
    static let choice6R = "Buy an expensive shoes"
    static let choice7R = "Board games"
    static let choice8R = "Read non fiction Books"
    static let choice9R = "Minimalism"
    static let choice10R = "Plant based food"
    static let rightChoices = [choice1R,choice2R,choice3R,choice4R,choice5R,choice6R,choice7R,choice8R,choice9R,choice10R]
  }
}

// MARK: - Results Texts
extension Texts {
  struct ResultTexts {
    static let resultText1 = "Congratulations! You have generated your own self."
    
    static let resultText2 = "You might be asking, what does the color mean, don't you?"
    
    static let resultText3 = "Here. Let me explain..."
    
    static let resultText4 = "As you might see, I represented short-term 'good' decisions with darker colors."
    
    static let resultText5 = "On the other hand, I represented long-term 'good' decisions with brighter colors."
    
    static let resultText6 = """
"Oh, so the brighter, the better person I am, and vice versa?"
"""
    
    static let resultText7 = "It's not! That's what I'm trying to point out in this playground."
    
    static let resultText8 = "Really, there were no good or bad decisions."
    
    static let resultText9 = "Every decision you made shaped who you are today,"
    
    static let resultText10 = "and that's what all matters."
    
    static let resultText11 = "Own your color. Own yourself."
    
    static let resultText12 = "It's your life after all."
    
    static let resultText13 = "Just remember..."
    
//    static let resultText14 = "Now take one more step, and live your life to the fullest!!!"
  }
}

extension Texts {
  struct CreditTexts {
    static let credits = """
    1. Background music: Memories from Bensound.com\n
    """
  }
}

