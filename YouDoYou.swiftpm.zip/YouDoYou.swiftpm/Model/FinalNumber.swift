//
//  File.swift
//  YouDoYou
//
//  Created by Hilmy Veradin on 16/04/22.
//

import Foundation
import UIKit

public var saveNumber1 : CGFloat = 0
public var saveNumber2 : CGFloat = 0
public var saveNumber3 : CGFloat = 0

